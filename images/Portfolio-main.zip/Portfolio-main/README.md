# 3d-portfolio
Personal Portfolio website designed using ThreeJS

1. `npm install` to install dependencies.  
2. `npm run dev` to start the development server.
